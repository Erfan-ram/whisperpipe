import stt
import pyaudio
import numpy as np
import time
from pynput import keyboard

# Load the Coqui STT model (optimized for CPU)
model = stt.Model("model.tflite")
stream = model.createStream()

# Audio parameters
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 16000
CHUNK = 1024

# Initialize PyAudio
p = pyaudio.PyAudio()
audio_stream = p.open(format=FORMAT,
                      channels=CHANNELS,
                      rate=RATE,
                      input=True,
                      frames_per_buffer=CHUNK)

# Flag to track if we should continue running
running = True

def on_press(key):
    global running
    try:
        if key.char == 'q':
            running = False
            return False  # Stop listener
    except AttributeError:
        pass

# Set up keyboard listener
listener = keyboard.Listener(on_press=on_press)
listener.start()

print("Listening... Press 'q' to stop")

try:
    while running:
        data = audio_stream.read(CHUNK, exception_on_overflow=False)
        audio_data = np.frombuffer(data, dtype=np.int16)
        
        # Feed audio data to the STT model
        stream.feedAudioContent(audio_data)
        
        # Get intermediate results for more responsive feedback
        text = stream.intermediateDecode()
        print(f"\rPartial: {text}", end="", flush=True)
        
        # Every second, check for final results
        if time.time() % 1 < 0.1:
            text = stream.finishStream()
            if text.strip():
                print(f"\nTranscription: {text}")
            stream = model.createStream()
            
except KeyboardInterrupt:
    print("\nStopped by user")
finally:
    audio_stream.stop_stream()
    audio_stream.close()
    p.terminate()
    if listener.is_alive():
        listener.stop()