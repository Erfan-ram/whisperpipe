from faster_whisper import WhisperModel
import pyaudio
import numpy as np
import threading
import time
from pynput import keyboard

class RealtimeTranscriber:
    def __init__(self, model_size="base.en"):
        # Use faster-whisper which uses CTranslate2 backend
        print(f"Loading Faster Whisper model: {model_size}...")
        self.model = WhisperModel(model_size, device="cpu", compute_type="int8")
        print("Model loaded!")
        
        # Audio recording parameters
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 16000
        self.CHUNK = 1024
        
        # Processing parameters
        self.audio_buffer = []
        self.is_recording = False
        self.last_processed = 0
        
        # Initialize PyAudio
        self.p = pyaudio.PyAudio()
        self.stream = None
    
    def _audio_callback(self, in_data, frame_count, time_info, status):
        audio_data = np.frombuffer(in_data, dtype=np.int16)
        self.audio_buffer.append(audio_data)
        return (in_data, pyaudio.paContinue)
    
    def _process_audio(self):
        while self.is_recording:
            # Process audio every 0.5 seconds for more responsive results
            if len(self.audio_buffer) > self.last_processed:
                new_chunks = self.audio_buffer[self.last_processed:]
                audio_data = np.hstack(new_chunks).astype(np.float32) / 32768.0
                
                # Process with faster-whisper
                segments, _ = self.model.transcribe(audio_data, beam_size=1, language="en")
                
                # Print out transcription
                for segment in segments:
                    print(f"{segment.text}")
                
                self.last_processed = len(self.audio_buffer)
            
            time.sleep(0.5)  # More frequent updates
    
    def start_streaming(self):
        """Start streaming from microphone and transcribing"""
        self.is_recording = True
        self.audio_buffer = []
        self.last_processed = 0
        
        # Open PyAudio stream
        self.stream = self.p.open(
            format=self.FORMAT,
            channels=self.CHANNELS,
            rate=self.RATE,
            input=True,
            frames_per_buffer=self.CHUNK,
            stream_callback=self._audio_callback
        )
        
        # Start processing thread
        self.process_thread = threading.Thread(target=self._process_audio)
        self.process_thread.daemon = True
        self.process_thread.start()
        
        print("Listening... (Press 'q' to stop)")
    
    def stop_streaming(self):
        """Stop streaming and clean up"""
        if not self.is_recording:
            return
            
        self.is_recording = False
        
        # Stop and close stream
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        
        # Wait for the processing thread to finish
        if hasattr(self, 'process_thread') and self.process_thread.is_alive():
            self.process_thread.join(timeout=2)
    
    def close(self):
        """Clean up resources"""
        self.stop_streaming()
        self.p.terminate()

if __name__ == "__main__":
    # Initialize the transcriber
    transcriber = RealtimeTranscriber(model_size="base.en")
    
    def on_press(key):
        try:
            if key.char == 'q':
                print("\nStopping transcription...")
                return False  # Stop listener
        except AttributeError:
            pass
    
    try:
        # Start the transcriber
        transcriber.start_streaming()
        
        # Set up keyboard listener
        with keyboard.Listener(on_press=on_press) as listener:
            listener.join()  # Wait for 'q' press
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        transcriber.stop_streaming()
        transcriber.close()
        print("Transcription ended.")