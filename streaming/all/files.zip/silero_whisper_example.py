import torch
from faster_whisper import WhisperModel
import numpy as np
import pyaudio
import collections
import time
from pynput import keyboard

# Load Silero VAD for voice activity detection
model, utils = torch.hub.load(repo_or_dir='snakers4/silero-vad',
                              model='silero_vad',
                              force_reload=True)
(get_speech_timestamps, _, read_audio, _, _) = utils

# Load Whisper
whisper_model = WhisperModel("base.en", device="cpu", compute_type="int8")

# Configure audio
chunk_size = 1024
sample_rate = 16000
window_size_seconds = 2
window = collections.deque(maxlen=int(window_size_seconds * sample_rate / chunk_size))

# Initialize PyAudio
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16,
                channels=1,
                rate=sample_rate,
                input=True,
                frames_per_buffer=chunk_size)

# Flag to track if we should continue running
running = True

def on_press(key):
    global running
    try:
        if key.char == 'q':
            running = False
            return False  # Stop listener
    except AttributeError:
        pass

# Set up keyboard listener
listener = keyboard.Listener(on_press=on_press)
listener.start()

print("Listening... Press 'q' to stop")

# Keep track of speech segments
is_speaking = False
speech_buffer = []

try:
    while running:
        data = stream.read(chunk_size, exception_on_overflow=False)
        audio_chunk = np.frombuffer(data, dtype=np.int16)
        window.append(audio_chunk)
        
        # Process when we have enough data
        if len(window) == window.maxlen:
            audio_data = np.concatenate(window)
            
            # Use Silero VAD to detect speech
            vad_prob = model(torch.from_numpy(audio_data.astype(np.float32) / 32768), sample_rate)
            speech_detected = vad_prob > 0.5
            
            if speech_detected and not is_speaking:
                # Speech started
                is_speaking = True
                speech_buffer = [audio_data]
            elif speech_detected and is_speaking:
                # Continuing speech
                speech_buffer.append(audio_data)
            elif not speech_detected and is_speaking:
                # Speech ended, process with Whisper
                if len(speech_buffer) > 0:
                    full_audio = np.concatenate(speech_buffer)
                    segments, _ = whisper_model.transcribe(full_audio.astype(np.float32) / 32768, beam_size=1)
                    for segment in segments:
                        print(f"{segment.text}")
                is_speaking = False
                speech_buffer = []

except KeyboardInterrupt:
    print("\nStopping...")
finally:
    stream.stop_stream()
    stream.close()
    p.terminate()
    if listener.is_alive():
        listener.stop()