from vosk import Model, KaldiRecognizer
import pyaudio
import json
import sys
from pynput import keyboard

# Select a smaller model size for better CPU performance
model_path = "vosk-model-small-en-us-0.15"

# Load model (the small model is only ~40MB)
try:
    model = Model(model_path)
    print("Model loaded successfully")
except Exception as e:
    print(f"Failed to load model: {e}")
    print("You may need to download the model first:")
    print("wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
    print("unzip vosk-model-small-en-us-0.15.zip")
    sys.exit(1)

# Initialize recognizer with sample rate matching your microphone
recognizer = KaldiRecognizer(model, 16000)

# Initialize PyAudio
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16, 
                channels=1, 
                rate=16000, 
                input=True, 
                frames_per_buffer=8000)

# Global flag to track if we should stop
running = True

def on_press(key):
    global running
    # Stop listening on pressing 'q'
    try:
        if key.char == 'q':
            running = False
            return False  # Stop listener
    except AttributeError:
        pass

# Set up keyboard listener
listener = keyboard.Listener(on_press=on_press)
listener.start()

print("Listening... Press 'q' to stop")

try:
    stream.start_stream()
    
    while running:
        data = stream.read(4000, exception_on_overflow=False)
        if recognizer.AcceptWaveform(data):
            # Final result
            result = json.loads(recognizer.Result())
            if result["text"]:
                print(f"YOU: {result['text']}")
        else:
            # Partial result
            partial = json.loads(recognizer.PartialResult())
            if partial["partial"]:
                # Print partial results (overwrite previous partial)
                print(f"\rPartial: {partial['partial']}", end="", flush=True)
except KeyboardInterrupt:
    print("\nStopped by user")
finally:
    stream.stop_stream()
    stream.close()
    p.terminate()
    if listener.is_alive():
        listener.stop()